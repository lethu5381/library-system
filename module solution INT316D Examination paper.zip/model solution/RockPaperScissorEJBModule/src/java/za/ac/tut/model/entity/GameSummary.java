/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.model.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;

/**
 *
 * @author MemaniV
 */
@Entity
public class GameSummary implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String userID;
    private String userName;
    private Integer numGamesPlayed;
    private Integer userScore;
    private Integer computerScore;
    private Integer numTies;
    @OneToMany(cascade = CascadeType.PERSIST, fetch = FetchType.EAGER)
    private List<ComputerGeneratedValue> computerValues;
    @OneToMany(cascade = CascadeType.PERSIST, fetch = FetchType.EAGER)
    private List<UserGuess> userGuesses;
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date creationDate;

    public GameSummary() {
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Integer getNumGamesPlayed() {
        return numGamesPlayed;
    }

    public void setNumGamesPlayed(Integer numGamesPlayed) {
        this.numGamesPlayed = numGamesPlayed;
    }

    public Integer getUserScore() {
        return userScore;
    }

    public void setUserScore(Integer userScore) {
        this.userScore = userScore;
    }

    public Integer getComputerScore() {
        return computerScore;
    }

    public void setComputerScore(Integer computerScore) {
        this.computerScore = computerScore;
    }

    public Integer getNumTies() {
        return numTies;
    }

    public void setNumTies(Integer numTies) {
        this.numTies = numTies;
    }

    public List<ComputerGeneratedValue> getComputerValues() {
        return computerValues;
    }

    public void setComputerValues(List<ComputerGeneratedValue> computerValues) {
        this.computerValues = computerValues;
    }

    public List<UserGuess> getUserGuesses() {
        return userGuesses;
    }

    public void setUserGuesses(List<UserGuess> userGuesses) {
        this.userGuesses = userGuesses;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof GameSummary)) {
            return false;
        }
        GameSummary other = (GameSummary) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "za.ac.tut.model.entity.GameSummary[ id=" + id + " ]";
    }
    
}
