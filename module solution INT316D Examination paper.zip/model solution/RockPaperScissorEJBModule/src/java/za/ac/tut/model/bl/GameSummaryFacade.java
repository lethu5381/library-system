/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.model.bl;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import za.ac.tut.model.entity.GameSummary;

/**
 *
 * @author MemaniV
 */
@Stateless
public class GameSummaryFacade extends AbstractFacade<GameSummary> implements GameSummaryFacadeLocal {

    @PersistenceContext(unitName = "RockPaperScissorEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public GameSummaryFacade() {
        super(GameSummary.class);
    }
    
    @Override
    public List<GameSummary> find(String id) {
        Query query = em.createQuery("SELECT gs FROM GameSummary gs WHERE gs.userID=?1");
        query.setParameter(1, id);
        List<GameSummary> targetGames = (List<GameSummary>)query.getResultList();
        return targetGames;
    }

    @Override
    public List<String> getWinners() {
        Query query = em.createQuery("SELECT gs.userName FROM GameSummary gs WHERE gs.userScore > gs.computerScore");
        List<String> winners = (List<String>)query.getResultList();
        return winners;
    }
    
}
