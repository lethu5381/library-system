/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.model.bl;

import javax.ejb.Stateless;

/**
 *
 * @author MemaniV
 */
@Stateless
public class RockPaperScissorSB implements RockPaperScissorSBLocal {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    private static final String[] signs = {"Rock", "Paper", "Scissor"};

    @Override
    public String generateSign() {
        int index = (int)Math.floor(Math.random()*3);
        return signs[index];
    }

    @Override
    public String determineOutcome(String userGuess, String computerValue) {
        String outcome = "tie";
        
        if((userGuess.equals("Rock")) && (computerValue.equals("Paper"))){
            outcome = "lost";
        } else if((userGuess.equals("Rock")) && (computerValue.equals("Scissor"))){
            outcome = "won";
        } else if((userGuess.equals("Paper")) && (computerValue.equals("Scissor"))){
            outcome = "lost";
        } else if((userGuess.equals("Paper")) && (computerValue.equals("Rock"))){
            outcome = "won";
        } else if((userGuess.equals("Scissor")) && (computerValue.equals("Rock"))){
            outcome = "lost";
        } else if((userGuess.equals("Scissor")) && (computerValue.equals("Paper"))){
            outcome = "won";
        } 
        
        return outcome;
    }
    
    
      
}
